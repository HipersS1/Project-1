#ifndef HEADER_H_INCLUDED
#define HEADER_H_INCLUDED

#include "Data.h"
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <string.h>
#include <stdbool.h>
#include <assert.h>
#include <time.h>
#include <unistd.h>

typedef struct subscriber *SUBSCRIBER;
typedef struct staff *STAFF;
typedef struct equipment *EQUIPMENT;
typedef struct lista *LIST;
typedef struct staff_list *STLIST;
typedef struct eq_list *EQLIST;


///Meniuri
void Menu();
void MenuSu();
void MenuSubscriber();
void MenuSt();
void MenuStaff();
void MenuEquipment();
void MenuEq();

///FUNCTII Abonati
LIST newList();
bool isEmpty(LIST l);
bool isFull();
void destroy(LIST l);
SUBSCRIBER search_subscriber(LIST l, int code);
LIST readFile_subscriber(LIST l,int *n);
LIST insertEnd_subscriber(LIST l,int code,char *name, char *firstname , char *type, char *va,long int Ed);
LIST add_subscriber(LIST l,int *n);
void rewriteFile_subscriber(LIST l);
LIST activate_subscription(LIST l);
LIST update_subscribers(LIST l);
LIST Time(LIST l);
char *toString_subscriber(LIST l,char *s);
void subscriber_stats(LIST l);

///Functii angajati
STLIST newList_staff();
bool isEmpty_staff(STLIST l);
bool isFull_staff();
void destroy_staff(STLIST l);
char *toString_staff(STLIST l, char *zone);
char *toString_staff_schedule(STLIST l,char *zone);
STLIST insertEnd_staff(STLIST l, int code, char *name, char *firstname, char *task, char *date);
STLIST add_staff(STLIST l,int *n);
void rewriteFile_staff(STLIST l, char *task);
STLIST readFile_staff(STLIST l,int *n);
STLIST schedule_staff(STLIST l);
void info_staff(STLIST l);
STLIST read_schedule(STLIST l);
STAFF search_staff(STLIST l, int code);
STLIST remove_staff(STLIST l);
STLIST remove_first(STLIST l);
STLIST remove_last(STLIST l);

///Functii echipamente
EQLIST newList_eq();
bool isEmpty_eq(EQLIST l);
bool isFull_eq();
void destroy_eq(EQLIST l);
EQLIST insertEnd_eq(EQLIST l, int code, char *name, char *category, time_t date, time_t vdate);
EQUIPMENT search_eq(EQLIST l, int code);
void rewriteFile_eq(EQLIST l, char *cateq, int bucati);
EQLIST readFile_eq(EQLIST l,int *n);
EQLIST add_eq(EQLIST l,int *n);
char *toString_eq(EQLIST l,char *zone);
EQLIST remove_eq(EQLIST l);
void inventory_info_eq(EQLIST l);
EQLIST activate_verificationDate(EQLIST l);

int printRandoms(int lower, int upper);


#endif // HEADER_H_INCLUDED
