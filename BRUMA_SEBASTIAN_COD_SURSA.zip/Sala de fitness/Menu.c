#include "Header.h"

void MenuSubscriber()
{
    char option;
    char *buffer;
    int Subscriptions = 1;
    LIST listS=newList();
    readFile_subscriber(listS,&Subscriptions);
    update_subscribers(listS);
    while(1)
    {
        buffer=malloc(Subscriptions*200*sizeof(char));
        MenuSu();
        switch(toupper(option=getch()))
        {
        case '1':
            system("cls");
            printf("%s\n",toString_subscriber(listS,buffer));
            printf(FORMAT1"Pentru a continua apasati orice tasta");
            getch();
            break;
        case '2':
            add_subscriber(listS,&Subscriptions);
            printf("\n"FORMAT1"Pentru a continua apasati orice tasta.");
            getch();
            break;
        case '3':
            system("cls");
            activate_subscription(listS);
            break;
        case '4':
            subscriber_stats(listS);
            break;
        case 'R':
            destroy(listS);
            free(buffer);
            return ;
        case 'X':
            destroy(listS);
            free(buffer);
            printf(FORMAT4"    Programul se inchide\n");
            exit(0);
        default:
            printf(FORMAT4"\t\b\b\033[0;31mOptiune invalida\033[0m");
            sleep(2);
        }
        free(buffer);
    }
}


void MenuStaff()
{
    char option;
    int staff=1;
    STLIST s=newList_staff();
    readFile_staff(s,&staff);
    char *buffer;
    while(1)
    {
        buffer=malloc(staff*150*sizeof(char));
        MenuSt();
        switch(toupper(option=getch()))
        {
        case '1':
            system("cls");
            printf("%s",toString_staff(s,buffer));
            printf("\n\n"FORMAT1"Pentru a continua apasati orice tasta");
            getch();
            break;
        case '2':
            add_staff(s,&staff);
            break;
        case '3':
            schedule_staff(s);
            break;
        case '4':
            remove_staff(s);
            break;
        case '5':
            info_staff(s);
            break;
        case 'R':
            destroy_staff(s);
            free(buffer);
            return;
        case 'X':
            destroy_staff(s);
            free(buffer);
            printf(FORMAT4"    Programul se inchide\n");
            exit(0);
        default:
            printf(FORMAT4"\t\b\b\033[0;31mOptiune invalida\033[0m");
            sleep(2);
            printf("\33[2K\r");
        }
        free(buffer);
    }
}


void MenuEquipment()
{
    char option;
    int eq=1;
    EQLIST e=newList_eq();
    readFile_eq(e,&eq);
    while(1)
    {
        char *buffer=malloc(eq*200*sizeof(char));
        MenuEq();
        switch(toupper(option=getch()))
        {
        case '1':
            system("cls");
            printf("%s",toString_eq(e,buffer));
            printf("\n\n"FORMAT1"Pentru a continua apasati orice tasta");
            getch();
            break;
        case '2':
            add_eq(e,&eq);
            printf("\n\n"FORMAT1"Pentru a continua apasati orice tasta");
            getch();
            break;
        case '3':
            remove_eq(e);
            break;
        case '4':
            activate_verificationDate(e);
            break;
        case '5':
            inventory_info_eq(e);
            getch();
            break;
        case 'R':
            destroy_eq(e);
            free(buffer);
            return;
        case 'X':
            destroy_eq(e);
            free(buffer);
            printf(FORMAT4"    Programul se inchide\n");
            exit(0);
        default:
            printf(FORMAT4"\t\b\b\033[0;31mOptiune invalida\033[0m");
            sleep(2);
            printf("\33[2K\r");
        }
        free(buffer);
    }
}


void Menu()
{
    system("cls");
    printf(FORMAT4"|------Meniu Principal-----|\n"
           FORMAT4"|1-Administrare abonamente |\n"
           FORMAT4"|2-Administrare angajati   |\n"
           FORMAT4"|3-Administrare echipamente|\n"
           FORMAT4"|X-Exit                    |\n"
           FORMAT4"|--------------------------|\n");
}


void MenuSu()
{
    system("cls");
    printf(FORMAT4"|------Meniu Abonati-------|\n"
           FORMAT4"|1-Afisare abonati         |\n"
           FORMAT4"|2-Adaugare abonat         |\n"
           FORMAT4"|3-Activare abonament      |\n"
           FORMAT4"|4-Statistica abonati      |\n"
           FORMAT4"|R-Meniu principal         |\n"
           FORMAT4"|X-Exit                    |\n"
           FORMAT4"|--------------------------|\n");
}


void MenuSt()
{
    system("cls");
    printf(FORMAT4"|------Meniu Angajati------|\n"
           FORMAT4"|1-Afisare angajati        |\n"
           FORMAT4"|2-Adaugare anagajat       |\n"
           FORMAT4"|3-Modifica program angajat|\n"
           FORMAT4"|4-Eliminare angajat       |\n"
           FORMAT4"|5-Informatii angajat      |\n"
           FORMAT4"|R-Meniu principal         |\n"
           FORMAT4"|X-Exit                    |\n"
           FORMAT4"|--------------------------|\n");
}


void MenuEq()
{
    system("cls");
    printf(FORMAT4"|-----Meniu Echipament-----|\n"
           FORMAT4"|1-Afisare echipamente     |\n"
           FORMAT4"|2-Adauga echipament       |\n"
           FORMAT4"|3-Sterge echipament       |\n"
           FORMAT4"|4-Informatii revizie      |\n"
           FORMAT4"|5-Raport inventar         |\n"
           FORMAT4"|R-Meniu principal         |\n"
           FORMAT4"|X-Exit                    |\n"
           FORMAT4"|--------------------------|\n");
}


int printRandoms(int lower, int upper)
{
    int i,num;
    for (i = 0; i < 1; i++)
    {
        num = (rand() % (upper - lower + 1)) + lower;
    }
    return num;
}
