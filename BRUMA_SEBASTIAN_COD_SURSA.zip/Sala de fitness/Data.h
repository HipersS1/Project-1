#ifndef DATA_H_INCLUDED
#define DATA_H_INCLUDED
#include <stdio.h>
#include <time.h>
#define FORMAT1 "\t\t\t\t\t\t\t\t"//continuare
#define FORMAT2 "\t\t\t\t\t\t"//staff
#define FORMAT5 "\t\t\t\t\t\t\t"
#define FORMAT3 "\t\t\t\t\t\t\t\t       "//optiune invalida
#define FORMAT4 "\t\t\t\t\t\t\t\t\t"
#include <string.h>
static char *toStringDATA_subscriber(int cod, char *nume, char *prenume, char *tip, char *va, char *zona)
{
    sprintf(zona,FORMAT2"|%d\t %-20s %-20s \t %-7s\t %s%-7s\033[0m|",cod,nume,prenume,tip,strcmp(va,"VALID")==0?"\033[0;32m":"\033[0;31m",va);
    return zona;
}


static char *toStringDATA_staff_schedule(int cod, char *nume, char *prenume, char *sarcina,char *program, char *zona)
{
    sprintf(zona,FORMAT2"|%d\t %-20s %-20s %-16s \t %s|",cod,nume,prenume,sarcina,program == NULL ? "\033[0;31mADAUGA\t    \033[0m":program);
    return zona;
}


static char *toStringDATA_staff(int cod, char *nume, char *prenume, char *sarcina, char *zona)
{
    sprintf(zona,FORMAT2"|%d\t %-20s %-20s %-16s|",cod,nume,prenume,sarcina);
    return zona;
}

static char *toStringDATA_eq(int cod, char *nume, char *categorie, time_t vdate, char *zona)
{
    time_t timp_actual;
    time(&timp_actual);
    sprintf(zona,FORMAT2" %d\t %-30s %-15s %s",cod,nume,categorie,timp_actual>vdate?"\033[0;31mNecesita revizie!\033[0m\n":asctime(localtime(&vdate)));
    return zona;
}

#endif // DATA_H_INCLUDED
