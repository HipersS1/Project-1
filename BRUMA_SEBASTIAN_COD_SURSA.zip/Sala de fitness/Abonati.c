#include "Header.h"

struct subscriber
{
    int Code;
    char *Name;
    char *Firstname;
    char *Type;
    char *Validity;
    long int ExpirationDay;
    struct subscriber *next;
};

typedef struct subscriber Subscriber;

struct lista
{
    int nr;
    SUBSCRIBER first;
    SUBSCRIBER last;
};

typedef struct lista List;

LIST newList()
{
    LIST header=(LIST)malloc(sizeof(List));
    if(header != NULL)
    {
        header->nr = 0;
        header->first = NULL;
        header->last = NULL;
    }
    return header;
}


static SUBSCRIBER newSubscriber(int code,char *name, char *firstname, char *type, char *va,long int Ed,SUBSCRIBER urmator)
{
    SUBSCRIBER p=(SUBSCRIBER)malloc(sizeof(Subscriber));
    if(p != NULL)
    {
        p->Code = code;
        p->Name = name;
        p->Firstname = firstname;
        p->Type = type;
        p->Validity = va;
        p->ExpirationDay = Ed;
        p->next = urmator;
    }
    return p;
}


bool isEmpty(LIST l)
{
    return l->nr == 0;
}


bool isFull()
{
    return false;
}


void destroy(LIST l)
{
    SUBSCRIBER e,p;
    if(l == NULL || l->first == NULL)
        return;
    e = l->first;
    while(e != NULL)
    {
        p = e;
        e = e->next;
        free(p);
    }
}


char *toString_subscriber(LIST l,char *s)
{
    char buff[200];
    char buffinfo[300];
    sprintf(s,FORMAT2"|\033[0;32mCod\t Nume\t\t      Prenume\t\t\t Tip\t\t Stare  \033[0m|\n");

    assert(l != NULL);

    if(isEmpty(l))
    {
        strcat(s,"\n"FORMAT1"NU EXISTA ABONATI IN BAZA DE DATE\n");
    }
    else
    {
        SUBSCRIBER e;
        for(e = l->first; e != NULL ; e = e->next)
        {
            sprintf(buff,"%s%c",toStringDATA_subscriber(e->Code,e->Name,e->Firstname,e->Type,e->Validity,buffinfo),e==l->last ? '\n' : '\n');
            strcat(s, buff);
        }
    }
    return s;
}


LIST insertEnd_subscriber(LIST l,int code,char *name, char *firstname, char *type, char *va,long int Ed)
{
    assert(l != NULL);
    SUBSCRIBER p = newSubscriber(code,name, firstname, type, va, Ed, NULL);

    if(isFull(l))
        return l;
    if( p != NULL)
    {
        if(isEmpty(l))
            l->first = l->last = p;
        else
        {
            l->last->next = p;
            l->last = p;
        }
        l->nr++;
    }
    return l;
}


LIST readFile_subscriber(LIST l,int *numarAbonati)
{
    assert(l != NULL);
    if(isFull(l))
        return l;

    char buffer[50];
    int cod;
    long int dezactivare;
    char *nume,*prenume,*tip,*va;

    FILE *f=fopen("Abonati.txt","r+");
    assert(f != NULL);

    fseek(f, 0, SEEK_END);
    int size = ftell(f);
    rewind(f);
    if(size == 0)
        return l;

    //citire numarul de abonati
    fscanf(f,"%d",numarAbonati);
    if(*numarAbonati == NULL)
    {
        *numarAbonati = 1;
        return l;
    }
    else if(*numarAbonati == 0)
        *numarAbonati = 1;
    else
    {
        for(int i=1; i<=*numarAbonati; i++)
        {
            //citire cod
            fscanf(f,"%d",&cod);

            //Citire nume
            fscanf(f,"%s",buffer);
            nume = malloc((strlen(buffer)+1)*sizeof(char));
            strcpy(nume,buffer);

            //Citire prenume
            fscanf(f,"%s",buffer);
            prenume = malloc((strlen(buffer)+1)*sizeof(char));
            strcpy(prenume,buffer);

            ///Citire tip abonament
            fscanf(f,"%s",buffer);
            tip = malloc((strlen(buffer)+1)*sizeof(char));
            strcpy(tip,buffer);

            ///Citire valabilitate abonament
            fscanf(f,"%s",buffer);
            va = malloc((strlen(buffer)+1)*sizeof(char));
            strcpy(va,buffer);

            fscanf(f,"%ld",&dezactivare);

            insertEnd_subscriber(l,cod,nume,prenume,tip,va,dezactivare);
        }
    }
    return l;
}


LIST add_subscriber(LIST l,int *numarAbonati)
{
    assert(l != NULL);
    system("cls");
    printf(FORMAT4"---Meniu adaugare abonat---\n\n");
    int cod;
    char buffer[30],*nume,*prenume,*tip,*v;
    char special_char[]=" 1234567890,<.>/?;:'[{]}-_=+";
    SUBSCRIBER p;
    srand(time(0));
    do
    {
        int ok=0;
        cod=printRandoms(1000,9999);
        for(p=l->first ; p != NULL ; p=p->next)
        {
            if(cod == p->Code)
            {
                ok=1;
                break;
            }
        }
        if(ok == 0)
            break;
    }
    while(1);
    while(1)
    {
        printf(FORMAT2"\tIntroduceti numele de familie:\t\t");
        gets(buffer);

        if(strlen(buffer) < 3 || strlen(buffer) > 20)
        {
            printf(FORMAT2"\t\033[0;31mIntroduceti un nume mai lung de 2 litere si mai scurt de 20 litere\033[0m");
            sleep(3);
            printf("\33[2K\r\033[A\33[2K");
            continue;
        }

        if(strpbrk(buffer,special_char)!= NULL)
        {
            printf(FORMAT2"\t\033[0;31mIntroduceti un nume fara caractere speciale(fara spatiu) sau cifre\033[0m");
            sleep(3);
            printf("\33[2K\r\033[A\33[2K");
            continue;
        }
        break;
    }
    strupr(buffer);
    nume=malloc((strlen(buffer)+1)*sizeof(char));
    strcpy(nume,buffer);

    //Citire prenume:
    while(1)
    {
        printf(FORMAT2"\tIntroduceti prenumele:\t\t\t");
        gets(buffer);
        if(strlen(buffer) < 3 || strlen(buffer) > 20)
        {
            printf(FORMAT2"\t\033[0;31mIntroduceti un prenume mai lung de 2 litere si mai scurt de 20 litere\033[0m");
            sleep(3);
            printf("\33[2K\r\033[A\33[2K");
            continue;
        }

        if(strpbrk(buffer,special_char)!= NULL)
        {
            printf(FORMAT2"\t\033[0;31mIntroduceti un prenume fara caractere speciale(fara spatiu) sau cifre\033[0m");
            sleep(3);
            printf("\33[2K\r\033[A\33[2K");
            continue;
        }
        break;
    }
    strupr(buffer);
    prenume=malloc((strlen(buffer)+1)*sizeof(char));
    strcpy(prenume,buffer);

    //Tip abonament:
    char optiune;
    do
    {
        printf(FORMAT5"\t\t\033[0;32mAlegeti tipul abonamentului\033[0m\n"FORMAT4"   1-Premium\t2-Simplu");
        optiune=getch();
        if(optiune == '1')
        {
            tip=malloc((strlen(buffer)+1)*sizeof(char));
            strcpy(tip,"PREMIUM");
            break;
        }
        if(optiune == '2')
        {
            tip=malloc((strlen(buffer)+1)*sizeof(char));
            strcpy(tip,"SIMPLU");
            break;
        }
        else
        {
            printf("\n"FORMAT3"\033[0;31mOptiune invalida\033[0m");
            sleep(2);
            printf("\33[2K\r\033[A\33[2K\033[A\33[2K");
        }
    }
    while(1);
    printf("\33[2K\033[A\33[2K\r");
    printf(FORMAT2"\tTipul abonamentului:\t\t\t%s\n",tip);

    v=malloc((strlen(buffer)+1)*sizeof(char));
    strcpy(v,"VALID");

    time_t seconds;

    time(&seconds);
    /// ziua de dezactivare a abonamentului
    printf(FORMAT2"\tData activare:\t\t\t\t%s",asctime(localtime(&seconds)));
    seconds=seconds + 2592000;
    printf(FORMAT2"\tData expirare:\t\t\t\t%s\n",asctime(localtime(&seconds)));
    printf(FORMAT2"\tAbonatul cu codul \033[0;32m%d\033[0m a fost adaugat in baza de date\n",cod);
    insertEnd_subscriber(l,cod,nume,prenume,tip,v,seconds);
    rewriteFile_subscriber(l);
    *numarAbonati=l->nr;

    return l;
}


void rewriteFile_subscriber(LIST l)
{
    assert( l != NULL);
    if(isEmpty(l))
        return ;
    FILE *f=fopen("Abonati.txt","w");
    if(f == NULL)
    {
        perror("Eroare");
        return;
    }
    fprintf(f,"%d\n",l->nr);
    SUBSCRIBER p;
    for(p=l->first ; p != NULL ; p=p->next)
    {
        fprintf(f,"%d ",p->Code);
        fprintf(f,"%s ",p->Name);
        fprintf(f,"%s ",p->Firstname);
        fprintf(f,"%s ",p->Type);
        fprintf(f,"%s ",p->Validity);
        fprintf(f,"%ld\n",p->ExpirationDay);
    }
    fclose(f);
}


LIST update_subscribers(LIST l)
{

    assert(l != NULL);
    if(isEmpty(l))
        return l;

    time_t seconds;
    time(&seconds);

    SUBSCRIBER p;
    int ok=0;

    for(p=l->first; p != NULL ; p=p->next)
    {
        if(p->ExpirationDay < seconds)
        {
            if(strcmp(p->Validity,"INVALID") == 0 )
                continue;
            p->Validity = malloc((strlen("INVALID")+1)*sizeof(char));
            strcpy(p->Validity,"INVALID");
            ok=1;
        }
        else if(p->ExpirationDay > seconds)
        {
            if(strcmp(p->Validity,"VALID") == 0 )
                continue;
            p->Validity = malloc((strlen("VALID")+1)*sizeof(char));
            strcpy(p->Validity,"VALID");
            ok=1;
        }
    }
    if(ok == 1)
        rewriteFile_subscriber(l);
    return l;
}


LIST activate_subscription(LIST l)
{
    assert(l != NULL);
    if(isEmpty(l))
    {
        printf(FORMAT3"\t\033[0;31mLISTA DE ABONATI ESTE VIDA\033[0m\n\n");
        printf(FORMAT3"\t\033[0;32m   APASATI ORICE TASTA\033[0m");
        getch();
        return l;
    }
    int code,reintroducere=-1;
    char codRe='1',bufcod[45];
    char *buffer=malloc(l->nr * 200);
    while(codRe == '1')
    {
        reintroducere = 0;
        printf("\n\n\n\n\n%s",toString_subscriber(l,buffer));
        for(int i=1; i<=l->nr+6; i++)
            printf("\033[A");

        printf(FORMAT2"\033[1;32mIntroduceti codul abonamentului:\033[0m");
        scanf("%s",bufcod);
        code = atoi(bufcod);
        SUBSCRIBER p;
        //Caut codul introdus
        if( (p=search_subscriber(l,code)) != NULL)
        {
            system("cls");
            printf(FORMAT2"   ---Activare abonament---\n\n");
            printf(FORMAT2"Cod  abonat\t\t%d\n"
                   FORMAT2"Nume abonat\t\t%s %s\n"
                   FORMAT2"Tip  abonament\t\t%s\n"
                   FORMAT2"Abonament    \t\t%s%s\033[0m\n",p->Code,p->Name,p->Firstname,p->Type,strcmp(p->Validity,"VALID")==0?"\033[0;32m":"\033[0;31m",p->Validity);
            //Daca abonamentul este invalid-deschid meniul de reactivare al abonamentului + schimbare tip abonament
            if(strcmp(p->Validity,"INVALID") == 0)
            {
                printf("\n"FORMAT2"1-Activare abonament\n"FORMAT2"2-Activare + Schimbare tip abonament\n"FORMAT2"3-Reintrodu cod abonat\n"
                       FORMAT2"4-Meniu abonati\n");
                char optiune;
                while((optiune=getch()))
                {
                    printf("\33[2K \033[A \33[2K \033[A \33[2K \033[A \33[2K \033[A \r");
                    if(optiune == '1' || optiune == '2')
                    {
                        long int luni;
                        time_t seconds;
                        time(&seconds);
                        if(optiune == '2')
                        {
                            if(strcmp(p->Type,"SIMPLU") == 0)
                            {
                                p->Type = malloc((strlen("PREMIUM")+1)*sizeof(char));
                                strcpy(p->Type,"PREMIUM");
                            }
                            else if(strcmp(p->Type,"PREMIUM") == 0)
                            {
                                p->Type = malloc((strlen("SIMPLU")+1)*sizeof(char));
                                strcpy(p->Type,"SIMPLU");
                            }
                            printf(FORMAT2"Tipul abonamentului a fost modificat in abonament \033[0;32m%s\033[0m\n",p->Type);
                        }

                        printf(FORMAT2"Activati abonamentul pentru 1-3 luni.\n");
                        while(1)
                        {
                            printf(FORMAT2"Introduceti numarul de luni:");
                            scanf("%s",bufcod);
                            luni = atoi(bufcod);
                            if(luni < 1 || luni > 3)
                            {
                                printf(FORMAT2"\033[0;31mNumarul de luni a fost introdus gresit\033[0m");
                                sleep(3);
                                printf("\33[2K\r\033[A\33[2K\r");
                            }
                            else
                                break;
                        };

                        p->Validity = malloc((strlen("VALID")+1)*sizeof(char));
                        strcpy(p->Validity,"VALID");

                        luni=luni * 2592000;
                        p->ExpirationDay=luni + seconds;
                        printf("\r\33[2K\033[A \33[2K\033[A\r");
                        printf(FORMAT2"Abonamentul cu codul \033[0;32m%d\033[0m a fost activat\n",p->Code);
                        printf(FORMAT2"Data activare:\t%s",asctime(localtime(&seconds)));
                        seconds+=luni;
                        printf(FORMAT2"Data expirare:\t%s\n",asctime(localtime(&seconds)));
                        rewriteFile_subscriber(l);
                        break;
                    }
                    if( optiune == '3')
                    {
                        reintroducere=1;
                        system("cls");
                        break;
                    }
                    if( optiune == '4')
                        return l;
                    else
                    {
                        printf(FORMAT2"\033[0;31mOptiune invalida\033[0m");
                        sleep(2);
                        printf("\33[2K\r");
                    }
                }
                if(reintroducere == 1)
                    continue;
            }
            ///Daca abonamentu e valid afisez data expirarii + revenire la meniul de abonati
            else if(strcmp(p->Validity,"VALID") == 0)
            {
                time_t seconds;
                seconds=p->ExpirationDay;
                printf(FORMAT2"Data expirare  \t\t%s\n",asctime(localtime(&seconds)));
            }
        }
        else
            printf(FORMAT2"\033[1;31mCodul %d nu exista in baza de date\033[0m\n",code);

        ///introducerea unui nou abonat sau revenire la meniu
        if(reintroducere == 0)
        {
            printf(FORMAT2"1-Introduceti alt cod\n"FORMAT2"R-Meniu abonati\n");
            while(1)
            {
                codRe=getch();
                if(codRe == '1')
                {
                    system("cls");
                    break;
                }
                else if(toupper(codRe) == 'R')
                    return l;
                else
                {
                    printf(FORMAT3"\033[0;31mOptiune invalida\033[0m");
                    sleep(2);
                    printf("\33[2K\r");
                }
            }
        }
    }

    free(buffer);
    return l;
}


SUBSCRIBER search_subscriber(LIST l, int code)
{
    assert(l!=NULL);

    if(!isEmpty(l))
    {
        SUBSCRIBER p;
        for(p=l->first; p!=NULL; p = p->next)
        {
            if(p->Code == code)
                return p;
        }
    }
    return NULL;
}


void subscriber_stats(LIST l)
{
    system("cls");
    assert(l != NULL);
    if(isEmpty(l))
    {
        printf(FORMAT3"\t\033[0;31mLISTA DE ABONATI ESTE VIDA\033[0m\n\n");
        printf(FORMAT3"\t\033[0;32m   APASATI ORICE TASTA\033[0m");
        getch();
        return;
    }
    SUBSCRIBER s;
    int totalPrem=0,totalSim=0,premVa=0,simpVa=0;

    for(s= l->first ; s != NULL ; s=s->next)
    {
        if(strcmp(s->Type,"PREMIUM")==0)
        {
            totalPrem++;
            if(strcmp(s->Validity,"VALID") == 0)
                premVa++;
        }
        if(strcmp(s->Type,"SIMPLU") == 0 && strcmp(s->Validity,"VALID") == 0 )
            simpVa++;
    }
    //l->nr total abonamente
    totalSim=l->nr - totalPrem;
    printf(FORMAT1"      ---Statistici abonamente---\n\n\n");
    printf(FORMAT5"Numar total de abonamente:%5d\n\n"
           FORMAT5"Abonamente Premium:%5d\tAbonamente Simple:%5d\n"
           FORMAT5"\t    Valide:%5d\t\t   Valide:%5d\n"
           FORMAT5"\t  Invalide:%5d\t\t Invalide:%5d\n",l->nr,totalPrem,totalSim,premVa,simpVa,totalPrem-premVa,totalSim-simpVa);
    printf("\n"FORMAT1"Pentru a continua apasati orice tasta.");
    getch();
    return;
}

