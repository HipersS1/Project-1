#include "Header.h"
struct staff
{
    int Code;
    char *Name;
    char *FirstName;
    char *Task;
    char *EmploymentDate;
    char *Schedule;
    struct staff *next;
};

typedef struct staff Staff;

struct staff_list
{
    int nr;
    STAFF first;
    STAFF last;
};
typedef struct staff_list StList;


STLIST newList_staff()
{
    STLIST header=(STLIST)malloc(sizeof(StList));
    if(header != NULL)
    {
        header->nr = 0;
        header->first = NULL;
        header->last = NULL;
    }
    return header;
}


static STAFF newStaff(int code,char *name,char *firstname,char *task,char *date,STAFF urmator)
{
    STAFF s=(STAFF)malloc(sizeof(Staff));

    if(s != NULL)
    {
        s->Code = code;
        s->Name = name;
        s->FirstName = firstname;
        s->Task = task;
        s->EmploymentDate = date;
        s->Schedule = NULL;
        s->next = urmator;
    }
    return s;
}


bool isEmpty_staff(STLIST l)
{
    return l->nr == 0;
}


bool isFull_staff()
{
    return false;
}


void destroy_staff(STLIST l)
{
    STAFF s,c;
    if(l == NULL || l->first == NULL)
        return;
    s = l->first;
    while(s!= NULL)
    {
        c = s;
        s = s->next ;
        free(c);
    }
}


char *toString_staff(STLIST l,char *zone)
{
    char buff[100];
    char buffinfo[100];
    sprintf(zone,FORMAT2"|\033[0;32mCod\t Nume\t\t      Prenume\t\t   Functie\t   \33[0m|\n");
    assert(l != NULL);

    if(isEmpty_staff(l))
        strcat(zone,"\n"FORMAT1"NU EXISTA ANGAJATI IN BAZA DE DATE\n");
    else
    {
        STAFF s;
        for(s = l->first ; s != NULL ; s = s->next)
        {
            sprintf(buff,"%s%c",toStringDATA_staff(s->Code,s->Name,s->FirstName,s->Task,buffinfo),s==l->last? ' ' : '\n');
            strcat(zone,buff);
        }
    }
    return zone;
}


char *toString_staff_schedule(STLIST l,char *zone)
{
    char buff[150];
    char buffinfo[150];
    sprintf(zone,FORMAT2"|\033[0;32mCod\t Nume\t\t      Prenume\t\t   Functie\t\t Program\33[0m    |\n");
    assert(l != NULL);

    if(isEmpty_staff(l))
        strcat(zone,"\n"FORMAT1"NU EXISTA ANGAJATI IN BAZA DE DATE\n");
    else
    {
        STAFF s;
        for(s = l->first ; s != NULL ; s = s->next)
        {
            sprintf(buff,"%s%c",toStringDATA_staff_schedule(s->Code,s->Name,s->FirstName,s->Task,s->Schedule,buffinfo),s==l->last? ' ' : '\n');
            strcat(zone,buff);
        }
    }
    return zone;
}


STLIST insertEnd_staff(STLIST l,int code,char *name,char *firstname,char *task,char *date)
{
    assert(l != NULL);
    STAFF s = newStaff(code,name,firstname,task,date,NULL);
    if(isFull_staff(l))
        return l;
    if( s != NULL)
    {
        if(isEmpty_staff(l))
            l->first= l->last = s;
        else
        {
            l->last->next = s;
            l->last = s;
        }
        l->nr++;
    }
    return l;
}


STLIST add_staff(STLIST l,int *n)
{
    assert(l != NULL);
    if(isFull_staff(l))
        return l;
    char *sarcina;
    system("cls");
    printf(FORMAT4"Meniu adaugare angajat\n\n"FORMAT2"\033[1;32mAlegeti functia angajatului\033[0m\n");
    printf(FORMAT2"1-Receptioner\n"
           FORMAT2"2-Antrenor\n"
           FORMAT2"3-Instructor\n"
           FORMAT2"4-Tehnician\n"
           FORMAT2"5-Personal curatenie\n"
           FORMAT2"R-Meniu angajati");
    char optiune;
    int code,min=-1,max=-1;
    srand(time(0));
    while(1)
    {
        optiune=getch();
        if(optiune == '1')
        {
            sarcina=malloc(strlen("RECEPTIONER")+1);
            strcpy(sarcina,"RECEPTIONER");
            min=100;
            max=199;
        }
        else if(optiune == '2')
        {
            sarcina=malloc(strlen("ANTRENOR")+1);
            strcpy(sarcina,"ANTRENOR");
            min=200;
            max=299;
        }
        else if(optiune == '3')
        {
            sarcina=malloc(strlen("INSTRUCTOR")+1);
            strcpy(sarcina,"INSTRUCTOR");
            min=300;
            max=399;
        }
        else if(optiune == '4')
        {
            sarcina=malloc(strlen("TEHNICIAN")+1);
            strcpy(sarcina,"TEHNICIAN");
            min=400;
            max=499;
        }
        else if(optiune == '5')
        {
            sarcina=malloc(strlen("PERSONAL")+1);
            strcpy(sarcina,"PERSONAL");
            min=500;
            max=599;
        }
        else if(toupper(optiune) == 'R')
        {
            return l;
        }
        else
        {
            printf("\n"FORMAT4"\033[0;31mOptiune invalida\033[0m");
            sleep(2);
            printf("\33[2K\r");
            continue;
        }
        break;
    }
    system("cls");
    printf(FORMAT4"Meniu adaugare angajat\n\n");
    printf(FORMAT2"Functia aleasa:\t\t\t\t\033[1;32m%s\033[0m\n",sarcina);
    STAFF p;
    do
    {
        int ok=0;
        code=printRandoms(min,max);
        if(isEmpty_staff(l))
            break;
        for(p=l->first ; p != NULL ; p=p->next)
        {
            if(code == p->Code)
            {
                ok=1;
                break;
            }
        }
        if(ok == 0)
            break;
    }
    while(1);

    char special_char[]="1234567890,<.>/?;:'[{]}-_=+ ";
    char buffer[100];
    char *nume,*prenume;
    fflush(stdin);
    for(int k=1; k<=2; k++)
    {
        while(1)
        {
            printf(FORMAT2"Introduceti %s",k==1?"numele de familie:\t\t":"prenumele:\t\t\t");
            gets(buffer);
            if(strlen(buffer) < 3 || strlen(buffer) > 20)
            {
                printf(FORMAT2"\033[0;31mIntroduceti un %s mai lung de 2 litere si mai scurt de 20 litere\033[0m",k==1?"nume de familie":"prenume");
                sleep(2);
                printf("\33[2K\r\033[A\33[2K");
                continue;
            }

            if(strpbrk(buffer,special_char)!= NULL)
            {
                printf(FORMAT2"\033[0;31mIntroduceti un %s fara caractere speciale(fara spatiu) sau cifre\033[0m",k==1?"nume de familie":"prenume");
                sleep(2);
                printf("\33[2K\r\033[A\33[2K");
                continue;
            }
            break;
        }
        strupr(buffer);
        if(k==1)
        {
            nume=malloc(strlen(buffer)+1);
            strcpy(nume,buffer);
        }
        else if(k==2)
        {
            prenume=malloc(strlen(buffer)+1);
            strcpy(prenume,buffer);
        }
    }

    char *dataAngajare;
    time_t data;
    time(&data);
    dataAngajare=malloc(strlen(asctime(localtime(&data)))+1);
    strcpy(dataAngajare,asctime(localtime(&data)));
    printf(FORMAT2"Data angajarii:\t\t\t\t%s\n",dataAngajare);
    printf(FORMAT2"Angajatul cu codul \033[1;32m%d\033[0m a fost inregistrat in baza de date\n",code);
    insertEnd_staff(l,code,nume,prenume,sarcina,dataAngajare);
    rewriteFile_staff(l,sarcina);

    *n = l->nr;
    printf("\n"FORMAT1"Pentru a continua apasati orice tasta");
    getch();
    return l;
}


void rewriteFile_staff(STLIST l,char *task)
{
    assert(l != NULL);
    if(isEmpty_staff(l))
        return ;
    FILE *f=fopen("Angajati.txt","r+");
    if(f==NULL)
    {
        perror("Eroare");
        return;
    }
    char *sarcina[]= {"RECEPTIONER","ANTRENOR","INSTRUCTOR","TEHNICIAN","PERSONAL"};
    int dimensiune=(sizeof(sarcina)/sizeof(char *));
    fseek(f, 0, SEEK_END);
    int size = ftell(f);
    rewind(f);
    if(size == 0)
    {
        fprintf(f,"%s 0\n%s 0\n%s 0\n%s 0\n%s 0\n",sarcina[0],sarcina[1],sarcina[2],sarcina[3],sarcina[4]);
        rewind(f);
    }
    int nr[dimensiune];
    char sarcinaFisier[100];
    for(int i=0; i<dimensiune; i++)
    {
        while(1)
        {
            fscanf(f,"%s",sarcinaFisier);
            while(strcmp(sarcinaFisier,sarcina[i]))
                fscanf(f,"%*[^\n]%s",sarcinaFisier);
            fscanf(f,"%d",&nr[i]);
            break;
        }
        rewind(f);
    }

    for(int i=0; i<dimensiune; i++)
    {
        if(strcmp(task,sarcina[i]) == 0 )
            nr[i]++;
    }

    rewind(f);
    STAFF s;
    for(int i=0; i<dimensiune; i++)
    {
        fprintf(f,"%s %d\n",sarcina[i],nr[i]);
        for(s=l->first; s!=NULL; s=s->next)
        {
            if(strcmp(sarcina[i],s->Task) == 0)
                fprintf(f,"%d %s %s %s %s",s->Code,s->Name,s->FirstName,s->Task,s->EmploymentDate);
        }
    }
    fclose(f);
}


STLIST readFile_staff(STLIST l,int *n)
{
    assert(l != NULL);
    if(isFull_staff(l))
        return l;
    FILE *f=fopen("Angajati.txt","r");
    if(f == NULL)
    {
        perror("Eroare");
        return l;
    }
    fseek(f, 0, SEEK_END);
    int size = ftell(f);
    rewind(f);
    if(size == 0)
        return l;
    char tmp[100];
    int angajati=-1,code=-1;
    char *name,*fname,*task,*date;
    char *sarcina[]= {"RECEPTIONER","ANTRENOR","INSTRUCTOR","TEHNICIAN","PERSONAL"};
    int dimensiune=(sizeof(sarcina)/sizeof(char *));
    for(int i=0; i<dimensiune; i++)
    {
        fscanf(f,"%s",tmp);
        task=malloc((strlen(tmp)+1)*sizeof(char));
        strcpy(task,tmp);
        fscanf(f,"%d",&angajati);
        if(angajati == 0)
            continue;
        for(int j=0; j<angajati; j++)
        {
            fscanf(f,"%d",&code);
            fscanf(f,"%s",tmp);
            name=malloc((strlen(tmp)+1)*sizeof(char));
            strcpy(name,tmp);

            fscanf(f,"%s",tmp);
            fname=malloc((strlen(tmp)+1)*sizeof(char));
            strcpy(fname,tmp);
            fscanf(f,"%s",tmp);

            fgets(tmp,100,f);
            date=malloc((strlen(tmp)+1)*sizeof(char));
            strcpy(date,tmp);

            insertEnd_staff(l,code,name,fname,task,date);
        }
    }
    if(l->nr == 0)
        *n=1;
    else
        *n=l->nr;
    fclose(f);

    STAFF s;
    FILE *g=fopen("ProgramAngajati.txt","r");
    if(g==NULL)
    {
        perror("Eroare:");
        return l;
    }
    int cod;
    for(s=l->first; s!=NULL; s=s->next)
    {
        fscanf(g,"%d",&cod);
        while(1)
        {
            if(cod != s->Code)
            {
                fscanf(g,"%*[^\n]%d",&cod);
            }
            else
            {
                fscanf(g,"%s",tmp);
                s->Schedule=malloc(strlen(tmp)+1);
                strcpy(s->Schedule,tmp);
                break;
            }
            if(feof(g))
                break;
        }
        rewind(g);
    }

    fclose(g);

    return l;
}


STLIST schedule_staff(STLIST l)
{
    assert(l!= NULL);
    system("cls");
    printf(FORMAT3"---MENIU PROGRAM ANGAJATI---\n");
    STAFF s;
    int cod=-1;
    char *tmp,buffcod[45];
    while(1)
    {
        if(isEmpty_staff(l))
            tmp=malloc(150);
        else
            tmp=malloc(l->nr*200);
        printf("\n\n\n%s",toString_staff_schedule(l,tmp));
        for(int i=0; i<l->nr+2; i++)
        {
            printf("\r\033[A\033[A\033[A");
            printf("\n");
        }
        free(tmp);
        if(l->nr == 0)
            break;
        printf(FORMAT2"Introduceti codul angajatului:");
        scanf("%s",buffcod);
        cod = atoi(buffcod);
        if((s=search_staff(l,cod)) != NULL)
            break;
        printf(FORMAT2"\033[1;31mCodul %d nu exista in baza de date\033[0m\n",cod);
        sleep(2);
        printf("\33[2K\033[A \33[2K \033[A \33[2K\r");
    }
    if(isEmpty_staff(l))
    {
        printf(FORMAT1"     Pentru a continua apasati orice tasta");
        getch();
        return l;
    }
    system("cls");
    printf(FORMAT3"\b---Informatii despre angajat---\n\n\n"
           FORMAT3"    Cod: \t\t%d\n"
           FORMAT3"   Nume: \t\t%s\n"
           FORMAT3"Prenume: \t\t%s\n"
           FORMAT3"Functie: \t\t%s\n",s->Code,s->Name,s->FirstName,s->Task);
    char option;
    char *interval[10]= {"08:00-15:00","15:00-22:00"};
    if(s->Schedule == NULL)
    {
        printf(FORMAT3"Program: \t\t\033[0;31mAdaugati program\033[0m\n");
        while(1)
        {
            printf("\n\n"FORMAT3"1-Adaugati programul de lucru\n"FORMAT3"R-Meniul angajatilor\n");
            option=getch();
            if(option == '1')
            {
                printf("\033[A\33[2K \033[A\33[2K \r");
                while(1)
                {
                    printf(FORMAT3"Alegeti intervalul de munca\n");
                    printf(FORMAT3"1-08:00 15:00\n"
                           FORMAT3"2-15:00 22:00\n");
                    option=getch();
                    if(option == '1')
                    {
                        s->Schedule=malloc(strlen(interval[0])+1);
                        strcpy(s->Schedule,interval[0]);
                        break;
                    }
                    else if(option == '2')
                    {
                        s->Schedule=malloc(strlen(interval[1])+1);
                        strcpy(s->Schedule,interval[1]);
                        break;
                    }
                    else
                    {
                        printf(FORMAT4"\t\b\b\033[0;31mOptiune invalida\033[0m");
                        sleep(2);
                        printf("\33[2K \033[A\33[2K \033[A\33[2K \033[A\33[2K \r");
                        continue;
                    }
                }
                printf("\33[2K \033[A \33[2K \033[A \33[2K \033[A \33[2K \033[A \33[2K \033[A \33[2K \033[A \33[2K\r");
                printf(FORMAT3"Program: \t\t\033[0;32m%s\033[0m\n",s->Schedule);
                break;
            }
            else if(toupper(option) == 'R')
                return l;
            else
            {
                printf(FORMAT4"\t\b\b\033[0;31mOptiune invalida\033[0m");
                sleep(2);
                printf("\33[2K\033[A \33[2K\033[A \33[2K\033[A \33[2K\033[A\r");
            }
        }
    }
    else
    {
        printf("\n"FORMAT3"\033[AProgram:\t\t\t%s\n\n",s->Schedule);
        while(1)
        {
            printf(FORMAT3"Doriti sa schimbati intervalul de munca?\n"
                   FORMAT3"1-Schimba intervalul\n"
                   FORMAT3"2-Meniu angajati\n");
            option=getch();
            if(option == '1')
            {
                printf("\33[2K \033[A \33[2K \033[A \33[2K \033[A \r");
                printf("\33[2K \033[A \33[2K \033[A\r");
                if(strcmp(s->Schedule,interval[0])==0)
                    strcpy(s->Schedule,interval[1]);
                else if(strcmp(s->Schedule,interval[1])==0)
                    strcpy(s->Schedule,interval[0]);
            }
            else if( option == '2')
                return l;
            else
            {
                printf(FORMAT4"\t\b\b\033[0;31mOptiune invalida\033[0m");
                sleep(2);
                printf("\33[2K \033[A\33[2K \033[A\33[2K \033[A\33[2K\r");
                continue;
            }
            printf("\n"FORMAT3"\033[AProgram:\t\t\t\033[0;32m%s\033[0m\n\n",s->Schedule);
            printf(FORMAT3"Programul a fost modificat");
            break;
        }
    }
    FILE *f=fopen("ProgramAngajati.txt","w");
    if(f == NULL)
    {
        perror("Eroare");
        return l;
    }
    for(s=l->first; s!=NULL; s=s->next)
    {
        if(s->Schedule != NULL)
            fprintf(f,"%d %s\n",s->Code,s->Schedule);
    }
    fclose(f);
    printf("\n\n"FORMAT1"     Pentru a continua apasati orice tasta");
    getch();
    return l;
}


void info_staff(STLIST l)
{
    assert(l!=NULL);
    if(isEmpty_staff(l))
    {
        system("cls");
        printf(FORMAT3"\t\033[0;31mLISTA DE ABONATI ESTE VIDA\033[0m\n\n");
        printf(FORMAT3"\t\033[0;32m   APASATI ORICE TASTA\033[0m");
        getch();
        return ;
    }
    STAFF s;
    int cod=-1;
    char *tmp,optiune,buffcod[45];
    while(1)
    {
        system("cls");
        printf(FORMAT3"---MENIU INFORMATII ANGAJATI---\n");
        while(1)
        {
            if(isEmpty_staff(l))
                tmp=malloc(150);
            else
                tmp=malloc(l->nr*200);
            printf("\n\n\n%s",toString_staff_schedule(l,tmp));
            for(int i=0; i<l->nr+2; i++)
            {
                printf("\r\033[A\033[A\033[A");
                printf("\n");
            }
            free(tmp);
            if(l->nr == 0)
                break;
            printf(FORMAT2"Introduceti codul angajatului:");
            scanf("%s",buffcod);
            cod = atoi(buffcod);
            if((s=search_staff(l,cod)) != NULL)
                break;
            printf(FORMAT2"\033[1;31mCodul %d nu exista in baza de date\033[0m\n",cod);
            sleep(2);
            printf("\33[2K\033[A \33[2K \033[A \33[2K\r");
        }
        system("cls");
        printf(FORMAT3"---MENIU INFORMATII ANGAJATI---\n\n\n");
        printf(FORMAT5"     Nume Prenume:\t\t\t%s %s\n",s->Name,s->FirstName);
        printf(FORMAT5"          Functie:\t\t\t%s\n"
               FORMAT5"          Program:\t\t\t%s\n",s->Task,s->Schedule==NULL?"\033[0;31mAdaugati\033[0m":s->Schedule);
        printf(FORMAT5"    Data angajare:\t\t      %s\n\n",s->EmploymentDate);

        while(1)
        {
            printf(FORMAT3"   1-Introduceti alt cod\n"
                   FORMAT3"   R-Meniu angajati\n");
            optiune = getch();
            if(optiune == '1')
                break;
            else if(toupper(optiune) == 'R')
                return;
            else
            {
                printf(FORMAT3"   \033[1;31mOptiune invalida\033[0m\n");
                sleep(2);
                printf("\33[2K\033[A\33[2K \033[A\33[2K \033[A\33[2K");
                continue;
            }
            break;
        }
    }
    return;
}


STAFF search_staff(STLIST l, int code)
{
    assert(l!=NULL);

    if(!isEmpty_staff(l))
    {
        STAFF p;
        for(p=l->first; p!=NULL; p = p->next)
        {
            if(p->Code == code)
                return p;
        }
    }
    return NULL;
}


STLIST remove_staff(STLIST l)
{
    assert(l!=NULL);
    STAFF s;
    char *tmp,buffcod[45];
    int cod;
    while(1)
    {
        system("cls");
        printf(FORMAT3"---Meniu stergere angajat---\n");
        while(1)
        {
            if(l->nr == 0)
                tmp=malloc(150);
            else
                tmp=malloc(l->nr*150);
            printf("\n\n\n\n\n%s",toString_staff(l,tmp));
            for(int i=0; i<=l->nr+4; i++)
            {
                printf("\r\033[A");
            }
            free(tmp);
            if(l->nr == 0)
                break;
            printf(FORMAT2"Introduceti codul angajatului:");
            scanf("%s",buffcod);
            cod = atoi(buffcod);
            if((s=search_staff(l,cod)) != NULL)
                break;
            printf(FORMAT2"\033[1;31mCodul %d nu exista in baza de date\033[0m\n",cod);
            sleep(2);
            printf("\33[2K\033[A\33[2K \033[A\33[2K");
        }
        if(l->nr > 0)
        {
            STAFF p;
            if(s==l->first)
                remove_first(l);
            else if(s==l->last)
                remove_last(l);
            else
                for(p=l->first; p!=NULL; p=p->next)
                {
                    if(p->next == s)
                    {
                        p->next = s->next;
                        free(s);
                        l->nr--;
                        break;
                    }
                }
            printf(FORMAT2"Angajatul avand codul \033[1;31m%d\033[0m a fost sters din baza de date\n",cod);
            char *sarcina[]= {"RECEPTIONER","ANTRENOR","INSTRUCTOR","TEHNICIAN","PERSONAL"};
            int dimensiune=sizeof(sarcina)/sizeof(char *);
            int angajati[5]= {0};
            for(int i=0; i<dimensiune; i++)
            {
                for(s=l->first; s!=NULL; s=s->next)
                {
                    if(strcmp(sarcina[i],s->Task)==0)
                        ++angajati[i];
                }
            }
            FILE *f=fopen("Angajati.txt","w");
            for(int i=0; i<dimensiune; i++)
            {
                fprintf(f,"%s %d\n",sarcina[i],angajati[i]);
                for(s=l->first; s!=NULL; s=s->next)
                {
                    if(strcmp(sarcina[i],s->Task)==0)
                        fprintf(f,"%d %s %s %s %s",s->Code,s->Name,s->FirstName,s->Task,s->EmploymentDate);
                }
            }
            fclose(f);
        }
        char optiune;
        while(1)
        {
            if(l->nr > 0)
            {
                printf(FORMAT2"1-Sterge alt angajat\n");
            }
            printf(FORMAT2"R-Meniu angajati\n");
            optiune = getch();
            if(optiune == '1' && l->nr > 0)
                break;
            else if(toupper(optiune) == 'R' )
                return l;
            else
            {
                printf(FORMAT3"\033[0;31mOptiune invalida\033[0m");
                sleep(2);
                if(l->nr > 0 )
                    printf("\33[2K\033[A\33[2K \033[A\33[2K\r");
                else
                    printf("\33[2K\033[A\33[2K\r");
            }
        }

    }
    return l;
}


STLIST remove_first(STLIST l)
{
    assert(l!=NULL);

    if(l->first!=NULL)
    {
        l->nr--;
        STAFF p = l->first->next;
        free(l->first);
        l->first = p;
        if(l->first == NULL )
            l->first=NULL;
    }
    return l;
}


STLIST remove_last(STLIST l)
{
    assert(l!=NULL);
    if(isEmpty_staff(l))
        return l;
    l->nr--;
    if(l->first == l->last)
    {
        free(l->first);
        l->first = l->last = NULL;
    }
    else
    {
        STAFF p;
        for(p=l->first; p->next!=l->last; p = p->next) ;
        free(l->last );
        p->next = NULL;
        l->last = p;
    }
    return l;
}

