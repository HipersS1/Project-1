#include "Header.h"

struct equipment
{
    int Code;
    char *Name;
    char *Category;
    time_t Date;
    time_t VerificationDate;
    struct equipment *next;
};

typedef struct equipment Equipment;

struct eq_list
{
    int nr;
    EQUIPMENT first;
    EQUIPMENT last;
};
typedef struct eq_list EqList;


EQLIST newList_eq()
{
    EQLIST header=(EQLIST)malloc(sizeof(EqList));
    if(header != NULL)
    {
        header->nr = 0;
        header->first = NULL;
        header->last = NULL;
    }
    return header;
}


static EQUIPMENT newEq(int code,char *name,char *category,time_t date,time_t vdate,EQUIPMENT urmator)
{
    EQUIPMENT s=(EQUIPMENT)malloc(sizeof(Equipment));

    if(s != NULL)
    {
        s->Code = code;
        s->Name = name;
        s->Category = category;
        s->Date = date;
        s->VerificationDate = vdate;
        s->next = urmator;
    }
    return s;
}


bool isEmpty_eq(EQLIST l)
{
    return l->nr == 0;
}


bool isFull_eq()
{
    return false;
}


void destroy_eq(EQLIST l)
{
    EQUIPMENT s,c;
    if(l == NULL || l->first == NULL)
        return;
    s = l->first;
    while(s!= NULL)
    {
        c = s;
        s = s->next ;
        free(c);
    }

}


EQLIST insertEnd_eq(EQLIST l,int code,char *name,char *category,time_t date,time_t vdate)
{
    assert(l != NULL);
    EQUIPMENT s = newEq(code,name,category,date,vdate,NULL);
    if(isFull_eq(l))
        return l;
    if( s != NULL)
    {
        if(isEmpty_eq(l))
            l->first= l->last = s;
        else
        {
            l->last->next = s;
            l->last = s;
        }
        l->nr++;
    }
    return l;
}


EQLIST add_eq(EQLIST l,int *n)
{
    assert(l!=NULL);
    if(isFull_eq(l))
        return l;
    char option;
    int cod;
    char *cat,*nume,buffcod[45];
    char *categorie[]= {"CARDIO","REZISTENTA","GREUTATI"};
    while(1)
    {
        system("cls");
        printf(FORMAT4"MENIU ADAUGARE ECHIPAMENT\n\n\n");
        printf(FORMAT4"Alegeti categoria echipamentului:\n"
               FORMAT4"1-Cardio\n"
               FORMAT4"2-Rezistenta\n"
               FORMAT4"3-Greutati\n"
               FORMAT4"R-Meniu echipamente\n");
        option=getch();
        if(option == '1')
        {
            cat=malloc(strlen(categorie[0])+1);
            strcpy(cat,categorie[0]);
        }
        else if(option == '2')
        {
            cat=malloc(strlen(categorie[1])+1);
            strcpy(cat,categorie[1]);
        }
        else if(option == '3')
        {
            cat=malloc(strlen(categorie[2])+1);
            strcpy(cat,categorie[2]);
        }
        else if(toupper(option) == 'R')
            return l;
        else
        {
            printf("\n"FORMAT4"\033[0;31mOptiune invalida\033[0m");
            sleep(2);
            continue;
        }
        break;
    }
    srand(time(0));
    cod=printRandoms(10000,99999);
    fflush(stdin);
    char buffer[100];
    system("cls");
    printf(FORMAT4"MENIU ADAUGARE ECHIPAMENT\n\n\n");
    printf(FORMAT2"Categoria echipamentului \033[0;32m%s\033[0m\n",cat);
    while(1)
    {
        printf(FORMAT2"Introduceti numele echipamentului:");
        gets(buffer);
        if(strlen(buffer) < 3 || strlen(buffer) > 30)
        {
            printf(FORMAT2"\033[0;31mNumele introdus este prea %s\033[0m",strlen(buffer) < 3?"scurt":"lung");
            sleep(2);
            printf("\33[2K\r\033[A\33[2K");
            continue;
        }
        break;
    }
    strupr(buffer);
    nume=malloc(strlen(buffer)+1);
    strcpy(nume,buffer);
    int numar_echipamente;
    printf(FORMAT2"Introduceti numarul de echipamente(1-10):");
    scanf("%s",buffcod);
    numar_echipamente = atoi(buffcod);
    while(numar_echipamente > 10 || numar_echipamente < 1)
    {
        if(numar_echipamente > 10)
            printf(FORMAT2"\033[0;31mNumarul introdus este prea mare\033[0m\n");
        else if(numar_echipamente < 1)
            printf(FORMAT2"\033[0;31mNumarul introdus este prea mic\033[0m\n");
        sleep(2);
        printf("\33[2K \033[A \33[2K \033[A \33[2K\r");
        printf(FORMAT2"Introduceti numarul de echipamente(1-10):");
        scanf("%s",buffcod);
        numar_echipamente = atoi(buffcod);
    }
    printf(FORMAT2"Introduceti perioada de revizie(1-12):");
    int revizie;
    scanf("%s",buffcod);
    revizie = atoi(buffcod);
    while(revizie < 1 || revizie > 12)
    {
        if(revizie > 12)
            printf(FORMAT2"\033[0;31mNumarul introdus este prea mare\033[0m");
        else if(revizie < 1)
            printf(FORMAT2"\033[0;31mNumarul introdus este prea mic\033[0m");
        sleep(2);
        printf("\33[2K \033[A \33[2K\r");
        printf(FORMAT2"Introduceti perioada de revizie(1-12):");
        scanf("%s",buffcod);
        revizie = atoi(buffcod);
    }
    time_t data,vdata;
    time(&data);
    time(&vdata);
    vdata = vdata + 2592000 * revizie;
    if(numar_echipamente == 0)
        printf("\n"FORMAT2"Echipamentul cu codul ");
    else
        printf("\n"FORMAT2"Echipamentele cu codurile ");
    for(int i=0; i<numar_echipamente; i++)
    {

        while(search_eq(l,cod))
            cod=printRandoms(10000,99999);
        printf("\033[0;32m%d \033[0m",cod);
        if(i == 5)
            printf("\n"FORMAT2);
        insertEnd_eq(l,cod,nume,cat,data,vdata);
    }
    if(numar_echipamente == 0)
        printf("a fost adaugat in baza de date\n");
    else
        printf("au fost adaugate in baza de date\n");
    rewriteFile_eq(l,cat,numar_echipamente);
    *n=l->nr;
    return l;
}


void rewriteFile_eq(EQLIST l,char *cateq,int bucati)
{
    assert(l != NULL);
    if(isEmpty_eq(l))
    {
        system("cls");
        printf("\n\n"FORMAT3"\033[0;31mNU EXISTA ECHIPAMENTE IN BAZA DE DATE\033[0m");
        printf("\n"FORMAT3"\033[0;32mPentru a continua apasati orice tasta\033[0m");
        return;
    }
    FILE *f=fopen("Echipamente.txt","r+");
    if(f==NULL)
    {
        perror("Eroare");
        return;
    }
    char *categorie[]= {"CARDIO","REZISTENTA","GREUTATI"};
    int dimensiune=(sizeof(categorie)/sizeof(char *));
    fseek(f, 0, SEEK_END);
    int size = ftell(f);
    rewind(f);
    if(size == 0)
    {
        fprintf(f,"%s 0\n%s 0\n%s 0\n",categorie[0],categorie[1],categorie[2]);
        rewind(f);
    }
    int nr[dimensiune];
    char tmp[100];
    for(int i=0; i<dimensiune; i++)
    {
        while(1)
        {
            fscanf(f,"%s",tmp);
            while(strcmp(tmp,categorie[i]))
                fscanf(f,"%*[^\n]%s",tmp);
            fscanf(f,"%d",&nr[i]);
            break;
        }
        rewind(f);
    }
    for(int i=0; i<dimensiune; i++)
    {
        if(strcmp(cateq,categorie[i]) == 0 )
            nr[i]+=bucati;
    }
    EQUIPMENT s;
    for(int i=0; i<dimensiune; i++)
    {
        fprintf(f,"%s %d\n",categorie[i],nr[i]);
        for(s=l->first; s!=NULL; s=s->next)
        {
            if(strcmp(categorie[i],s->Category) == 0)
                fprintf(f,"%d %s,%ld,%ld\n",s->Code,s->Name,s->Date,s->VerificationDate);
        }
    }
    fclose(f);
}


EQLIST readFile_eq(EQLIST l,int *n)
{
    assert(l != NULL);
    if(isFull_eq(l))
        return l;
    FILE *f=fopen("Echipamente.txt","r");
    if(f == NULL)
    {
        perror("Eroare");
        return l;
    }
    char tmp[100];
    int cod=-1,echipamente=-1;
    char *nume,*cat,*data,*vdata;
    char *categorie[]= {"CARDIO","REZISTENTA","GREUTATI"};
    int dimensiune=(sizeof(categorie)/sizeof(char *));

    char *p;
    for(int i=0; i<dimensiune; i++)
    {
        fscanf(f,"%s",tmp);
        cat=malloc((strlen(tmp)+1)*sizeof(char));
        strcpy(cat,tmp);
        fscanf(f,"%d",&echipamente);
        if(echipamente == 0)
            continue;
        for(int j=0; j<echipamente; j++)
        {
            fscanf(f,"%d ",&cod);
            fgets(tmp,150,f);
            p = strtok(tmp,",");
            nume=malloc(strlen(p)+1);
            strcpy(nume,p);

            p = strtok(NULL,",");
            data = malloc(strlen(p)+1);
            strcpy(data,p);
            p = strtok(NULL," ");
            vdata = malloc(strlen(p)+1);
            strcpy(vdata,p);

            long long dat,vdat;
            char *eptr;
            dat = strtoll(data,&eptr,0);
            vdat = strtoll(vdata,&eptr,0);

            insertEnd_eq(l,cod,nume,cat,dat,vdat);
        }
    }
    if(l->nr == 0)
        *n=1;
    else
        *n=l->nr;
    fclose(f);
    return l;
}


char *toString_eq(EQLIST l,char *zone)
{
    char buff[100];
    char buffinfo[150];
    sprintf(zone,FORMAT2"|\033[0;32mCod\t Nume\t\t\t\tCategorie\tVerificare\033[0m\t\t|\n");
    assert(l != NULL);

    if(isEmpty_eq(l))
        strcat(zone,FORMAT3"\033[0;31mNU EXISTA ECHIPAMENTE IN BAZA DE DATE\033[0m");
    else
    {
        EQUIPMENT s;
        for(s = l->first ; s != NULL ; s = s->next)
        {
            sprintf(buff,"%s",toStringDATA_eq(s->Code,s->Name,s->Category,s->VerificationDate,buffinfo));
            strcat(zone,buff);
        }
    }
    return zone;
}


EQUIPMENT search_eq(EQLIST l, int code)
{
    assert(l!=NULL);

    if(!isEmpty_eq(l))
    {
        EQUIPMENT p;
        for(p=l->first; p!=NULL; p = p->next)
        {
            if(p->Code == code)
                return p;
        }
    }
    return NULL;
}


EQLIST remove_eq(EQLIST l)
{
    assert(l!=NULL);
    if(isEmpty_eq(l))
    {
        system("cls");
        printf("\n\n"FORMAT3"\033[0;31mNU EXISTA ECHIPAMENTE IN BAZA DE DATE\033[0m");
        printf("\n\n"FORMAT3"\033[0;32mPentru a continua apasati orice tasta\033[0m");
        getch();
        return l;
    }
    EQUIPMENT s;
    char *tmp,optiune,buffcod[45];
    int cod;
    while(1)
    {
        system("cls");
        printf(FORMAT3"Meniu stergere echipament.\n");
        while(1)
        {
            tmp=malloc(l->nr*150);
            printf("\n\n\n\n\n%s",toString_eq(l,tmp));
            for(int i=0; i<=l->nr+4; i++)
            {
                printf("\r\033[A\033[A\033[A");
                printf("\n");
            }
            free(tmp);
            printf(FORMAT2"Introduceti codul echipamentului:");
            scanf("%s",buffcod);
            cod = atoi(buffcod);
            if((s=search_eq(l,cod)) != NULL)
                break;
            printf(FORMAT2"\033[0;31mAcest cod nu exista in baza de date\033[0m");
            sleep(2);
            printf("\33[2K\033[A\33[2K");
        }
        EQUIPMENT p;
        if(s==l->first)
        {
            l->nr--;
            EQUIPMENT p = l->first->next;
            free(l->first);
            l->first = p;
            if(l->first == NULL )
                l->first=NULL;
        }
        else if(s==l->last)
        {
            l->nr--;
            if(l->first == l->last)
            {
                free(l->first);
                l->first = l->last = NULL;
            }
            else
            {
                EQUIPMENT p;
                for(p=l->first; p->next!=l->last; p = p->next) ;
                free(l->last );
                p->next = NULL;
                l->last = p;
            }
        }
        else
            for(p=l->first; p!=NULL; p=p->next)
            {
                if(p->next == s)
                {
                    p->next = s->next;
                    free(s);
                    l->nr--;
                    break;
                }
            }
        char *categorie[]= {"CARDIO","REZISTENTA","GREUTATI"};
        int dimensiune=(sizeof(categorie)/sizeof(char *));
        int echipamente[dimensiune];
        for(int i=0; i<dimensiune; i++)
        {
            echipamente[i]=0;
            for(s=l->first; s!=NULL; s=s->next)
            {
                if(strcmp(categorie[i],s->Category) == 0)
                    ++echipamente[i];
            }
        }
        FILE *f=fopen("Echipamente.txt","wt");

        for(int i=0; i<dimensiune; i++)
        {
            fprintf(f,"%s %d\n",categorie[i],echipamente[i]);
            for(s=l->first; s!=NULL; s=s->next)
            {
                if(strcmp(categorie[i],s->Category)==0)
                    fprintf(f,"%d %s,%ld,%ld\n",s->Code,s->Name,s->Date,s->VerificationDate);
            }
        }
        fclose(f);
        printf(FORMAT2"Echipamentul cu codul \033[0;32m%d\033[0m a fost sters din baza de date\n",cod);

        while(1)
        {
            if(!isEmpty_eq(l))
                printf(FORMAT2"1-Introduceti alt cod\n");
            printf(FORMAT2"R-Meniu echipamente");
            optiune = getch();
            if(optiune == '1' && l->nr != 0)
                break;
            else if( toupper(optiune) == 'R')
                return l;
            else
            {
                printf("\n"FORMAT4"\033[0;31mOptiune invalida\033[0m");
                sleep(2);
                if(l->nr > 0)
                    printf("\33[2K\033[A \33[2K\033[A \33[2K\r");
                else
                    printf("\33[2K\033[A \33[2K\r");
                continue;
            }
            break;
        }
    }
    return l;
}


void inventory_info_eq(EQLIST l)
{
    assert(l != NULL);
    if(isEmpty_eq(l))
    {
        system("cls");
        printf("\n\n"FORMAT3"\033[0;31mNU EXISTA ECHIPAMENTE IN BAZA DE DATE\033[0m");
        printf("\n\n"FORMAT3"\033[0;32mPentru a continua apasati orice tasta\033[0m");
        return;
    }
    system("cls");
    printf(FORMAT1"\033[0;32mPentru a continua apasati orice tasta\033[0m\n\n");
    char *categorie[]= {"CARDIO","REZISTENTA","GREUTATI"};
    char *vector[l->nr];
    for (int i=0 ; i<l->nr; i++)
    {
        if ((vector[i] = calloc(40,sizeof(char))) == NULL)
        {
            printf("unable to allocate memory \n");
            return;
        }
    }

    int dimensiune=(sizeof(categorie)/sizeof(char *));
    EQUIPMENT e;
    int n=0,ok=-1,j=-1;
    strcpy(vector[n],l->first->Name);
    for(e=l->first; e!=NULL; e=e->next)
    {
        ok=0;
        j=0;
        do
        {
            if(strcmp(vector[j],e->Name) == 0 )
            {
                ok=1;
                break;
            }
            if(ok == 1)
                break;
            j++;
        }
        while(j<=n);
        if(ok == 0)
        {
            n++;
            strcpy(vector[n],e->Name);
        }
    }
    int echipamente=0;
    for(int i=0; i<l->nr; i++)
    {
        if(strcmp(vector[i],"")!=0)
            echipamente++;
    }

    int buc_categorie[dimensiune];
    for(int i=0; i<dimensiune; i++)
    {
        buc_categorie[i]=0;
        for(e=l->first; e!=NULL; e=e->next)
        {
            if(strcmp(categorie[i],e->Category)==0 )
                buc_categorie[i]++;
        }
    }
    int buc[echipamente];
    for(int i=0; i<echipamente; i++)
    {
        buc[i]=0;
        for(e=l->first; e!=NULL; e=e->next)
        {
            if(strcmp(vector[i],e->Name) == 0 )
                buc[i]++;
        }
    }
    printf(FORMAT1"Inventar categorie\n");
    for(int i=0; i<dimensiune; i++)
    {
        printf(FORMAT1"%-15sx%d\n",categorie[i],buc_categorie[i]);
    }
    printf("\n"FORMAT1"Inventar echipamente\n");
    for(int i=0; i<echipamente; i++)
    {
        printf(FORMAT1"%-40sx%d\n",vector[i],buc[i]);
    }

}


EQLIST activate_verificationDate(EQLIST l)
{
    assert(l != NULL);
    if(isEmpty(l))
    {
        system("cls");
        printf("\n\n"FORMAT3"\033[0;31mNU EXISTA ECHIPAMENTE IN BAZA DE DATE\033[0m");
        printf("\n\n"FORMAT3"\033[0;32mPentru a continua apasati orice tasta\033[0m");
        getch();
        return l;
    }
    int code,reintroducere=-1;
    char codRe='1',buffcod[45];
    time_t timp;
    EQUIPMENT p;
    system("cls");
    while(codRe == '1')
    {
        char *buffer=malloc(l->nr * 200);
        reintroducere = 0;
        printf("\n\n\n\n\n%s",toString_eq(l,buffer));
        free(buffer);
        for(int i=1; i<=l->nr+6; i++)
            printf("\033[A");

        printf(FORMAT2"\033[1;32mIntroduceti codul echipamentului:\033[0m");
        scanf("%s",buffcod);
        code = atoi(buffcod);
        time(&timp);
        if( (p=search_eq(l,code)) != NULL)
        {
            system("cls");
            printf(FORMAT3"   ---Activare perioada revizie---\n\n");
            printf(FORMAT2"Cod  echipament\t\t\t%d\n"
                   FORMAT2"Nume echipament\t\t\t%s\n"
                   FORMAT2"Tip  echipament\t\t\t%s\n"
                   FORMAT2"Data revizie    \t\t%s\n",p->Code,p->Name,p->Category,asctime(localtime(&p->Date)));
            printf(FORMAT2"Data expirare   \t\t%s%s\033[0m",p->VerificationDate > timp?"\033[0;32m":"\033[0;31m",asctime(localtime(&p->VerificationDate)));
            if(p->VerificationDate < timp)
            {
                printf("\n"FORMAT2"1-Prelungirea reviziei\n"FORMAT2"2-Reintrodu cod\n"
                       FORMAT2"R-Meniu abonati\n");
                char optiune;
                EQUIPMENT s;
                while((optiune=getch()))
                {
                    printf("\33[2K \033[A \33[2K \033[A \33[2K \033[A \33[2K \033[A \33[2K \033[A\r");

                    if(optiune == '1')
                    {
                        time_t diferenta;
                        diferenta = (p->VerificationDate - p->Date) / 2592000 ;
                        p->Date = p->VerificationDate;
                        p->VerificationDate += diferenta * 2592000;
                        printf(FORMAT2"Data expirare   \t\t\033[0;32m%s\033[0m\n",asctime(localtime(&p->VerificationDate)));
                        printf(FORMAT2"Perioada de revizie a fost reinnoita(lunix%ld)\n",diferenta);
                        char *categorie[]= {"CARDIO","REZISTENTA","GREUTATI"};
                        int dimensiune=(sizeof(categorie)/sizeof(char *));
                        int echipamente[dimensiune];
                        for(int i=0; i<dimensiune; i++)
                        {
                            echipamente[i]=0;
                            for(s=l->first; s!=NULL; s=s->next)
                            {
                                if(strcmp(categorie[i],s->Category) == 0)
                                    ++echipamente[i];
                            }
                        }
                        FILE *f=fopen("Echipamente.txt","wt");

                        for(int i=0; i<dimensiune; i++)
                        {
                            fprintf(f,"%s %d\n",categorie[i],echipamente[i]);
                            for(s=l->first; s!=NULL; s=s->next)
                            {
                                if(strcmp(categorie[i],s->Category)==0)
                                    fprintf(f,"%d %s,%ld,%ld\n",s->Code,s->Name,s->Date,s->VerificationDate);
                            }
                        }
                        fclose(f);
                        break;
                    }
                    if( optiune == '2')
                    {
                        reintroducere=1;
                        break;
                    }
                    if( toupper(optiune) == 'R')
                        return l;
                    else
                    {
                        printf(FORMAT2"\033[0;31mOptiune invalida\033[0m");
                        sleep(2);
                        printf("\33[2K\r");
                    }
                }
                if(reintroducere == 1)
                    continue;
            }
            else if(p->VerificationDate > time)
            {
                printf("\n"FORMAT2"Nu este necesara verificarea echipamentului\n");
            }
        }
        else
            printf(FORMAT2"\033[1;31mCodul %d nu exista in baza de date\033[0m\n",code);

        if(reintroducere == 0)
        {
            printf(FORMAT2"1-Introduceti alt cod\n"FORMAT2"R-Meniu abonati\n");
            while(1)
            {
                codRe=getch();
                if(codRe == '1')
                {
                    system("cls");
                    break;
                }
                else if(toupper(codRe) == 'R')
                    return l;
                else
                {
                    printf(FORMAT3"\033[0;31mOptiune invalida\033[0m");
                    sleep(2);
                    printf("\33[2K\r");
                }
            }
        }
    }
    return l;
}
