#include "Header.h"

int main()
{
    char option;
    while(1)
    {
        Menu();
        switch(toupper(option=getch()))
        {
        case '1':
            MenuSubscriber();
            break;
        case '2':
            MenuStaff();
            break;
        case '3':
            MenuEquipment();
            break;
        case 'X':
            printf(FORMAT4"    Programul se inchide\n");
            exit(1);
        default:
            printf(FORMAT4"\t\b\b\033[0;31mOptiune invalida\033[0m");
            sleep(2);
        }
    }
    return 0;
}
